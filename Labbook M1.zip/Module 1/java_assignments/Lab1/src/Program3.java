import java.util.Scanner;

public class Program3 {
	boolean checkNumber(int number) {
		boolean check = true;
		int count = 0;
		int n = number;
		while (n > 0) {
			n = n / 10;
			count++;
		}
		int prev = 9;
		while (number > 0) {
			int r = number % 10;
			number = number / 10;
			if (prev >= r) {
				count--;
				prev = r;
			}
		}
		if (count == 0) {
			check = true;
		} else {
			check = false;
		}
		return check;
	}

	public static void main(String[] args) {
		Program3 p = new Program3();
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		int number = s.nextInt();
		System.out.println(p.checkNumber(number));

		// TODO Auto-generated method stub

	}

}
