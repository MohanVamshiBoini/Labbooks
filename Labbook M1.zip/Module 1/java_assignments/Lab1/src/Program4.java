import java.util.Scanner;

public class Program4 {
	boolean checkNumber(int n){
		boolean check=false;
		int i;
		if(n%2!=0){
			return check;
		}
		else{
			for(i=2;i<=n;i=i*2){
				if(i==n){
					return check=true;
				}
			}
		}
		return check;
		}

	public static void main(String[] args) {
		Program4 p=new Program4();
		@SuppressWarnings("resource")
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		System.out.println(p.checkNumber(n));// TODO Auto-generated method stub

	}

}
