import java.util.Scanner;

public class Program2 {
	int calaculateDifference(int n) {
		int a, b, c;
		a = (n * (n + 1) * ((2 * n) + 1)) / 6;
		b = ((n * (n + 1)) / 2) * ((n * (n + 1)) / 2);
		c = a - b;
		return c;
	}

	public static void main(String[] args) {
		Program2 p = new Program2();
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		System.out.println(p.calaculateDifference(n));// TODO Auto-generated
														// method stub

	}

}
