import java.util.Scanner;

public class Program3 {
	String getImage(String a){
		StringBuilder s1=new StringBuilder(a);
		s1.reverse();
		String b=s1.toString();
		return b;
	}

	public static void main(String[] args) {
		System.out.println("enter the string");
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		Program3 p=new Program3();
		System.out.println(s+" | "+p.getImage(s) );
		// TODO Auto-generated method stub

	}

}
