import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Program9 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the last date");
		String s1=sc.next();
		SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yy");
//		Date d1 = null;
		Date d1=new Date();
	    Date d2 = null;
	    try {
	      //d1 = sd.parse(s);
	        d2 = sd.parse(s1);
	    } catch (ParseException e) {
	        e.printStackTrace();
	    }
	    long diff = d1.getTime() - d2.getTime();
	    long diffDays = diff / (24 * 60 * 60 * 1000);
	    long diffMonth = diffDays/30;
	    long diffYears = diffMonth/12;
        System.out.println("Time in days: " + diffDays + " days");
	    System.out.println("Time in months: " + diffMonth+ " months");
	    System.out.println("Time in years: " + diffYears + " years");

	}

}
