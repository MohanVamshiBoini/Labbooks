import java.util.Scanner;

public class Program1 {
	int sumOfDigits(int n){
		int r,sum=0;
		while(n>0){
			r=n%10;
			n=n/10;
			sum=sum+(r*r*r);
		}
		return sum;
		
	}

	public static void main(String[] args) {
		int n;
		Program1 p=new Program1();// TODO Auto-generated method stub
		@SuppressWarnings("resource")
		Scanner s=new Scanner(System.in);
		System.out.println("enter the number");
		n=s.nextInt();
		System.out.println(p.sumOfDigits(n));

	}

}
