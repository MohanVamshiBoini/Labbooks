import java.util.Scanner;
@FunctionalInterface
interface E
{ int power(int n1,int n2);
}
	public class Program1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n and m");
		int n=sc.nextInt();
		int m=sc.nextInt();
		
		@SuppressWarnings("resource")
		E s3=(n1,n2)->{return (int) Math.pow(n1,n2);};
		System.out.println(n+" power "+m +" is "+s3.power(n, m));
		sc.close();// TODO Auto-generated method stub

	}

}
