interface Functionable
{
	void func();
}
interface Functionable1
{
	String func();
}
class Student {
	static int id;
	String name;
	@SuppressWarnings("static-access")
	public Student() {
         this.id=18;
         this.name="Name";
	}
	public static void getId() {
		System.out.println(id);
	}
		public String getName() {
		return name;
	}
}
public class Program4{
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Student s=new Student();
		//constructor calling
		Functionable f=Student::new;
		//instance method calling using reference
		Functionable1 f1=s::getName;
		System.out.println(f1.func());
		//static method calling
		Functionable f2=Student::getId;
		f2.func();
	}
}