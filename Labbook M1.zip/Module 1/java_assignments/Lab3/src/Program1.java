import java.util.Scanner;

public class Program1 {
	int getSecondSmallest(int a[]) {
		int c,i;
		for (i = 0; i < a.length; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if (a[i] > a[j]) {
					c = a[i];
					a[i] = a[j];
					a[j] = c;
				}
			}
		}
			//System.out.println(a[1]);
		return a[1];
	}
	public static void main(String[] args) {

		Program1 d = new Program1();
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		System.out.println("enter no.of elements");
		int n = s.nextInt();
		int[] a = new int[n];
		System.out.println("enter array elements");
		for (int k = 0; k < n; k++) {
			a[k] = s.nextInt();
		}
		System.out.println(d.getSecondSmallest(a));
	}
}
