import java.util.Scanner;

public class Program4 {
	void counting(char[] c) {
		int i, j, count = 0;
		for (i = 0; i < c.length; i++) {
			if (c[i] == '9') {
				continue;
			}
			for (j = i + 1, count = 1; j < c.length; j++) {
				if (c[i] == c[j]) {
					count++;
					c[j]='9';
				}
			}
			System.out.println(c[i]+ "  repeadted  "+count);
		}

	}

	public static void main(String[] args) {
		Program4 e = new Program4();
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		System.out.println("enter string");
		String a = s.next();
		char[] c = new char[a.length()];
		for (int k = 0; k < a.length(); k++) {
			c[k] = a.charAt(k);// TODO Auto-generated method stub
		}
		e.counting(c);

	}

}

