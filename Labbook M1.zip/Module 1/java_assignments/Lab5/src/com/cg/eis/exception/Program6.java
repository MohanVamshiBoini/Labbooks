package com.cg.eis.exception;

import java.util.Scanner;

@SuppressWarnings("serial")
class EmployeeException extends Throwable {
	public EmployeeException(String errorMsg) {
		super(errorMsg);
	}
}

public class Program6 {
	static void validation(int salary) throws EmployeeException {
		if (salary < 3000) {
			throw new EmployeeException("Salary less the 3000");
		} else {
			System.out.println("Salary is above 3000");
		}
	}

	public static void main(String[] args) throws EmployeeException {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("enter salary");
		Program6.validation(sc.nextInt());

	}

}
