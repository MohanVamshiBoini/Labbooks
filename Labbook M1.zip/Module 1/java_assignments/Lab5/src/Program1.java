import java.util.Scanner;

public class Program1 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("enter your choice \n1=RED \n2=YELLOW \n3=GREEN");
		int a=sc.nextInt();
		if(a==1){
			System.out.println("STOP");
		}
		else if(a==2){
			System.out.println("READY");
		}
		else if(a==3){
			System.out.println("GO");
		}
		else{
			System.out.println("enter valid input");
		}

	}

}
