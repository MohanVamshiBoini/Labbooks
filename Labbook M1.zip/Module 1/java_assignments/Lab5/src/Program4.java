import java.util.Scanner;
@SuppressWarnings("serial")
class InvalidUserId extends Throwable {
	public InvalidUserId(String s) {
		super(s);
	}
}
public class Program4 {
	static void login(String firstName, String lastName) throws InvalidUserId {
		if (firstName.equals("") | lastName.equals("")) {
			throw new InvalidUserId("enter valid name");
		} else {
			System.out.println("valid");
		}
	}
	@SuppressWarnings("resource")
	public static void main(String[] args) throws InvalidUserId {
		System.out.println("first name");
		Scanner sc1 = new Scanner(System.in);
		String a=sc1.nextLine();
		System.out.println("last name");
		Scanner sc2 = new Scanner(System.in);
		String b=sc2.nextLine();
		Program4.login(a, b);// TODO Auto-generated
														// method stub

	}

}
