import java.util.Scanner;

public class Program3 {
	int[] getSorted(int a[]) {
		int i, j, c;
		String s1;
		for (i = 0; i < a.length; i++) {
			s1 = Integer.toString(a[i]);
			StringBuffer sb = new StringBuffer(s1);
			sb.reverse();
			a[i] = Integer.parseInt(sb.toString());
			// System.out.println(sb.reverse());
		}
		for (i = 0; i < a.length; i++)
			for (j = i + 1; j < a.length; j++)
				if (a[i] > a[j]) {
					c = a[i];
					a[i] = a[j];
					a[j] = c;
				}

		return a;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int k;
		Program3 p = new Program3();
		Scanner s = new Scanner(System.in);
		System.out.println("Enter n");
		int n = s.nextInt();
		System.out.println("Enter array elements");
		int[] a = new int[n];
		for (k = 0; k < n; k++)
			a[k] = s.nextInt();
		a = p.getSorted(a);
		for (k = 0; k < a.length; k++)
			System.out.println(a[k]);
		s.close();
	}
}
