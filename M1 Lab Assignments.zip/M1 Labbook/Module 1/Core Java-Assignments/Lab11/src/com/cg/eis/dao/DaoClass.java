package com.cg.eis.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.eis.bean.Employee;

public class DaoClass implements DaoInterface {
	static HashMap<Integer, Employee> h = new HashMap<Integer, Employee>();
	public void add(Employee e) {
		// TODO Auto-generated method stub
		h.put(e.getId(), e);
		System.out.println("successfully added");
		System.out.println(h.get(e.getId()));
	}

	public Employee selectData(int nid) {
		System.out.println(" in dao class");
		return h.get(nid);
	}

	public void getAllData() {
		// TODO Auto-generated method stub
		Set set = h.entrySet();
		Iterator i = set.iterator();
		System.out.println("EID\tNAME\tSALARY\tDESIGNATION\tSCHEMA");
		while (i.hasNext()) {
			Entry entry = (Entry) i.next();
			// int i1 = (Integer) entry.getKey();
			// if (i1 == id) {
			// b=true;
			System.out.print(entry.getKey() + "\t");
			System.out.println(entry.getValue());
		}
	}
}
