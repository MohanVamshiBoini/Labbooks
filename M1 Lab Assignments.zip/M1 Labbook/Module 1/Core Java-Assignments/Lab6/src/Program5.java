import java.util.Scanner;

public class Program5 {
	int modifyNumber(int number1) {
		int j, k, c;
		String s = Integer.toString(number1);
		StringBuffer s1 = new StringBuffer();
		for (int i = 0; i < s.length() - 1; i++) {
			j = (int) s.charAt(i);
			k = (int) s.charAt(i + 1);
			c=Math.abs(j-k);
			s1.append(c);
		}
		s1.append(s.charAt((int) s.length() - 1));
		int num = Integer.parseInt(s1.toString());
		return num;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Program5 p = new Program5();
		Scanner s = new Scanner(System.in);
		int number1 = s.nextInt();
		System.out.println(p.modifyNumber(number1));
		s.close();
	}

}
