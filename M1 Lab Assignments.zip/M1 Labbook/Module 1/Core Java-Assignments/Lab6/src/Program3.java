import java.util.Scanner;

public class Program3 {
	String getImage(String s1) {
		StringBuffer s2 = new StringBuffer(s1);
		s2 = s2.reverse();
		s1 = s2.toString();
		return s1;
	}

	public static void main(String[] args) {
		Program3 p = new Program3();
		Scanner s = new Scanner(System.in);
		String s1 = s.next();
		System.out.println(s1 + "|" + p.getImage(s1));
		s.close();

	}
}
