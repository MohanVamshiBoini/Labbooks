import java.util.Scanner;

public class Program4 {
	String alterString(String s1) {
		char[] a = s1.toCharArray();
		String s2=new String();
		for (int i = 0; i < s1.length(); i++)
			{if (a[i] >= 'A' && a[i] <= 'Z' || a[i] >= 'a' && a[i] <= 'z')
				if (!(a[i] == 'a' || a[i] == 'e' || a[i] == 'i' || a[i] == 'o' || a[i] == 'u' || a[i] == 'A'
						|| a[i] == 'E' || a[i] == 'I' || a[i] == 'O' || a[i] == 'U')) {
					a[i] = (char) (a[i] + 1);
				}
			s2+=a[i];
			}
		 return s2;
	}

	public static void main(String[] args) {
		Program4 p = new Program4();
		Scanner s = new Scanner(System.in);
		String s1 = s.nextLine();
		System.out.println(p.alterString(s1));
		s.close();

	}
}
