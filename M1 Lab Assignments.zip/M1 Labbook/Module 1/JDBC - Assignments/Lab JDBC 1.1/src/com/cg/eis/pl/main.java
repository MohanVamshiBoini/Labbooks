package com.cg.eis.pl;

import com.cg.eis.service.EmployeeService;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class main {

	public static void main(String[] args) throws SQLException {
		int empId = 0;
		String empDesg = "";
		String empName = "";
		float empSal = 0;
		int a = 0;
		Scanner s = new Scanner(System.in);
		int z = 2;
		while (z > 0) {
			System.out.println("1.add employee details");
			System.out.println("2.search employee details");
			System.out.println("3.update employee details");
			System.out.println("4.show all employee details");
			System.out.println("5.Delete employee details");
			System.out.println("6.exit");
			a = s.nextInt();

			switch (a) {

			case 1:
				System.out.println("Enter employee id");
				empId = s.nextInt();
				System.out.println("Enter employee designation");
				empDesg = s.next();
				System.out.println("Enter employee name");
				empName = s.next();
				System.out.println("Enter employee salary");
				empSal = s.nextFloat();
				EmployeeService empService = new EmployeeService();
				int updateCount = empService.addEmployee(empId, empDesg, empName, empSal);
				System.out.println("Inserted " + updateCount + " record");
				z--;
				break;
			case 2:
				System.out.println("enter employee id");
				empId = s.nextInt();
				EmployeeService empService1 = new EmployeeService();
				ResultSet empinfo = empService1.searchEmployee(empId);
				while (empinfo.next()) {
					System.out.println(empinfo.getInt(1) + " " + empinfo.getString(2) + " " + empinfo.getString(3) + " "
							+ empinfo.getString(4) + " " + empinfo.getInt(5));
				}
				z--;
				break;
			case 3:
				System.out.println("enter employee id");
				empId =s.nextInt();
				EmployeeService empService2 = new EmployeeService();
				int updated = empService2.updateEmployee(empId);
				if(updated>0){
					System.out.println("Updated");
				}
				else
					System.out.println("Not Updated");
			case 4:
				EmployeeService empService3 = new EmployeeService();
				ResultSet show = empService3.showEmployee();
				while (show.next()) {
					System.out.println(show.getInt(1) + " " + show.getString(2) + " " + show.getString(3) + " "
							+ show.getString(4) + " " + show.getInt(5));
				}
				z--;
				break;
			case 5:
				System.out.println("enter employee id");
				empId =s.nextInt();
				EmployeeService empService4 = new EmployeeService();
				int delete = empService4.deleteEmployee(empId);
				if(delete>0){
					System.out.println("Deleted");
				}
				else
					System.out.println("No Id Found");
				z--;
				break;
				
			case 6:
				z = 0;
			}
		}
	}

}
